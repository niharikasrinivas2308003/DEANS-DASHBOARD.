const mysql = require('mysql2/promise');
const connection = mysql.createPool({
    host: 'bdno1c1ihtxyi4gaepew-mysql.services.clever-cloud.com',
    user: 'u7ywa0kxq6db3dxq',
    password: 'FJ6H9nEENGW2zaDoqio6',
    database: 'bdno1c1ihtxyi4gaepew',
    connectionLimit: 5,
  });
// Testing the connection
(async () => {
  try {
    await connection.query('SELECT 1');
    console.log('Connected to database!');
  } catch (error) {
    console.error('Error connecting to database:', error);
    process.exit(1); // Exit the process if unable to connect to the database
  }
})();

module.exports = connection;