const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'bdno1c1ihtxyi4gaepew-mysql.services.clever-cloud.com',
  user: 'u7ywa0kxq6db3dxq',
  password: 'FJ6H9nEENGW2zaDoqio6',
  database: 'bdno1c1ihtxyi4gaepew'
});

connection.connect((err) => {
  if (err) {
    console.error('Error connecting to database: ' + err.stack);
    return;
  }
  console.log('Connected to database as id ' + connection.threadId);
});

module.exports = connection;
