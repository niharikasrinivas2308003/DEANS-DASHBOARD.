import streamlit as st
import pandas as pd
import plotly.express as px
import mysql.connector

# Function to connect to the database
def connect_to_database():
    endpoint = "bdno1c1ihtxyi4gaepew-mysql.services.clever-cloud.com"
    username = "u7ywa0kxq6db3dxq"
    password = "FJ6H9nEENGW2zaDoqio6"
    database = "bdno1c1ihtxyi4gaepew"
    connection = mysql.connector.connect(
        host=endpoint,
        user=username,
        password=password,
        database=database
    )
    cursor = connection.cursor()
    return connection, cursor

# Function to fetch data from the database
def fetch_data(cursor):
    query = """select year,
      number_of_new_full_programs, 
      number_of_new_domains, 
      number_of_new_skill_courses, 
      highest_H_index, 
      lowest_H_index, 
      faculty_with_zero_H_index, 
      number_of_domains_eligible_for_school, 
      percentage_of_domains_offered, 
      approximate_income_of_school, 
      cost_of_faculty_including_non_teaching from som_data"""
    cursor.execute(query)
    result = cursor.fetchall()
    df = pd.DataFrame(result, columns=[col[0] for col in cursor.description])
    return df

def generate_stacked_bar_chart(df):
    fig = px.bar(df, 
                 x='year', 
                 y=['number_of_new_full_programs', 'number_of_new_domains', 'number_of_new_skill_courses'],
                 labels={'value': 'Counts', 'year': 'Year'},
                 barmode='stack')
    yaxis=dict(title='',tickfont=dict(size=25)),  
    fig.update_layout(xaxis=dict(tickfont=dict(size=25)),yaxis=dict(categoryorder='total ascending',title=""),yaxis_showticklabels=False,xaxis_title_font=dict(size=25), legend=dict(font=dict(size=25),x=0.1,y=1.1,orientation='h'),legend_title=None, showlegend=True,height=600,width=800, autosize=True, hoverlabel=dict(font=dict(size=25,color="black")))
    fig.update_traces(texttemplate='%{y}', textposition='inside', textfont_size=30)    
    
    return fig


# Function to plot Exam Performance with year filter
def generate_scatter_line_chart(df):
    fig = px.scatter(df, x='year', y='highest_H_index',
                     labels={'highest_H_index': 'Highest H-index', 'year': 'Year'})
    
    fig.add_scatter(x=df['year'], y=df['lowest_H_index'], mode='lines+markers', name='Lowest H-index')
    fig.add_scatter(x=df['year'], y=df['faculty_with_zero_H_index'], mode='lines+markers', name='Faculty with Zero H-index')
    fig.add_scatter(x=df['year'], y=df['highest_H_index'], 
                mode='markers+lines', name='highest_H_index')
    # Update layout for better aesthetics 
    fig.update_layout(height=600,width=800,
        xaxis=dict(
            tickmode='linear',
            tick0=df['year'].min(),
            dtick=1,
            tickformat='d',  
            title='Year',
            tickfont=dict(size=20)
        ),
        yaxis=dict(tickfont=dict(size=20),title=""),xaxis_title_font=dict(size=25),
        legend=dict(
            title='',
            orientation='h',
            yanchor='bottom',font=dict(size=20),
            y=1.02,
            x=0.25
        ),
        font=dict(
            family='Arial, sans-serif',
            size=12,
            color='#333333'  # Set font color
        ),
    )
    fig.update_traces(marker=dict(size=20),  
                  line=dict(width=3),  
                  hoverinfo='x+y',  
                  hoverlabel=dict(font=dict(size=25,color='black')),  
                  mode='lines+markers'  
                  )
    
    return fig

def plot_stacked_pie_chart(data, selected_years):
    filtered_df = data[data['year'].isin(selected_years)]
    filtered_df["percentage_of_domains_not_offered"]= 100 - filtered_df['percentage_of_domains_offered']
    domains_offered = filtered_df['percentage_of_domains_offered'].sum()
    domains_not_offered = filtered_df['percentage_of_domains_not_offered'].sum()
    pie_data = pd.DataFrame({
        'category': ['Offered', 'Not Offered'],
        'percentage': [domains_offered, domains_not_offered]
    })
    fig = px.pie(pie_data, values='percentage', names='category',
                 color_discrete_map={'Offered': 'green', 'Not Offered': 'red'})
    fig.update_traces(textinfo='percent', textfont_size=25)
    fig.update_layout(
        legend=dict(title=None, font=dict(size=25),x=0.78,y=0.50),
        height=600,
        width=600,
        hoverlabel=dict(font=dict(size=25,color='black')),
    )
    return fig


# Function to plot MEME Students Over Years with year filter
def plot_Income_Vs_Cost_over_years(data, selected_years):
    fig = px.scatter(data, x='year', y='approximate_income_of_school', 
                 labels={'approximate_income_of_school': 'Approx. Income'})
    fig.add_scatter(x=data['year'], y=data['cost_of_faculty_including_non_teaching'], 
                mode='lines+markers', name='Cost (including non-teaching)')
    fig.add_scatter(x=data['year'], y=data['approximate_income_of_school'], 
                mode='markers+lines', name='Approx. Income')
    fig.update_layout(height=600,width=800,
        xaxis=dict(
            tickmode='linear',
            tick0=data['year'].min(),
            dtick=1,
            tickformat='d',  
            title='Year',
            tickfont=dict(size=20)
        ),
        yaxis=dict(tickfont=dict(size=20),title=""),xaxis_title_font=dict(size=25),
        legend=dict(
            title='',
            orientation='h',
            yanchor='bottom',font=dict(size=20),
            y=1.02,
            x=0.35
        ),
        font=dict(
            family='Arial, sans-serif',
            size=12,
            color='#333333'  
        ),
    )
    fig.update_traces(marker=dict(size=20),  
                  line=dict(width=3),  
                  hoverinfo='x+y',  
                  hoverlabel=dict(font=dict(size=25,color='black')),  
                  mode='lines+markers'  
                  )   
    return fig  



def main():
    st.set_page_config(page_title="SOM - College Dashboard", page_icon="📊", layout="wide")

    # Add custom CSS for styling
    st.markdown(
        """
        <style>
        .main {
            background-color: #FFA500;
            padding: 1rem;
        }

        .card {
            background-color: white;
            padding: 1rem;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .dashboard-title {
            background-color: #377eb8;
            color: white;
            padding: 1rem;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: -2rem;
            margin-top:-3rem;
        }

        [data-baseweb="tag"] {
            width:8rem;
            height:4rem;
        } 

        [data-title="Box Select"],[href="https://plotly.com/"],[data-title="Lasso Select"],[data-title="Pan"],[data-title="Zoom"]{
            display:None;
        }

        .st-ar{
            font-size:25px;
        }



        .st-ci{
            width:1.8rem;
            height:1.8rem;
        }

        .st-af{
            font-size:1.8rem;
        }
        
        [data-testid="stTable"]{
            font-size:30px;
            background-color:white;
        }

        [title="open"]{
            width:4rem;
            height:4rem;
            cursor:pointer;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Fetch data from database
    connection, cursor = connect_to_database()
    df = fetch_data(cursor)
    connection.close()

    # Display sections
    st.markdown("<h1 class='dashboard-title' style='text-align:center;'>College Dashboard</h1>", unsafe_allow_html=True)

    # Sidebar for filtering
    years_filter = st.multiselect(label="",label_visibility='hidden', options=df["year"].unique(), default=df["year"][-1:])

    col1, col2 = st.columns(2)

    with col1:
        st.markdown("<h1 class='card' style='text-align:center;'>New Programs, Domains, and Skill Courses by Year</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(generate_stacked_bar_chart(df), use_container_width=True)

        st.markdown("<h1 class='card' style='text-align:center;'>H-Index Over Years</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(generate_scatter_line_chart(df), use_container_width=True)

    with col2:
        st.markdown("<h1 class='card' style='text-align:center;'>Percentage of Domains Offered vs. Not Offered</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(plot_stacked_pie_chart(df,years_filter), use_container_width=True)

        st.markdown("<h1 class='card' style='text-align:center;'>Income Vs Cost over Years</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(plot_Income_Vs_Cost_over_years(df, years_filter), use_container_width=True)
    st.table(df)
if __name__ == "__main__":
    main()
