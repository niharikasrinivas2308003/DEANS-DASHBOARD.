import streamlit as st
import pandas as pd
import plotly.express as px
import mysql.connector

# Function to connect to the database
def connect_to_database():
    endpoint = "bdno1c1ihtxyi4gaepew-mysql.services.clever-cloud.com"
    username = "u7ywa0kxq6db3dxq"
    password = "FJ6H9nEENGW2zaDoqio6"
    database = "bdno1c1ihtxyi4gaepew"
    connection = mysql.connector.connect(
        host=endpoint,
        user=username,
        password=password,
        database=database
    )
    cursor = connection.cursor()
    return connection, cursor

# Function to fetch data from the database
def fetch_data(cursor):
    query = """select year,
      faculty_percent, 
      PhD_faculty_percent, 
      seminars_conferences_percent, 
      scopus_number_of_faculty, 
      core_of_WoS_number_of_faculty, 
      zero_publications_faculty_percent from soas_data"""
    cursor.execute(query)
    result = cursor.fetchall()
    df = pd.DataFrame(result, columns=[col[0] for col in cursor.description])
    return df

def plot_faculty_stacked_bar(data_filtered, selected_years):
  data_stacked = data_filtered.groupby('year')[['faculty_percent', 'PhD_faculty_percent']].sum().reset_index()
  fig = px.bar(data_stacked, x='year', y=['faculty_percent', 'PhD_faculty_percent'],
               labels={'year': 'Year', 'faculty_percent': 'Faculty', 'PhD_faculty_percent': 'Faculty with PhD'},
               barmode='stack')
  fig.update_layout(
      xaxis=dict(title='Year', tickfont=dict(size=25)),
      yaxis=dict(title='', tickfont=dict(size=25)),
      legend=dict(title=None, font=dict(size=25),orientation='h',y=1.15,x=0.30),
      height=600,
      width=800,
      hoverlabel=dict(font=dict(size=25,color='black')),yaxis_showticklabels=False
  )
  fig.update_traces(texttemplate='%{y}', textposition='inside', textfont_size=25)
  return fig

def plot_seminars(data):
    fig = px.line(data, x='year', y='seminars_conferences_percent',
                  labels={'year': 'Year', 'seminars_conferences_percent': 'Count'},
                  line_shape='spline',  
                  line_dash_sequence=['solid'],  
                  render_mode='svg', 
                  )
    fig.update_traces(marker=dict(size=20),  
                      line=dict(width=3),  
                      hoverinfo='x+y',  
                      hoverlabel=dict(font=dict(size=25,color='black')),  
                      mode='lines+markers'  
                      )
    fig.update_layout(
        xaxis=dict(title='Year', tickfont=dict(size=25),titlefont=dict(size=30)),  
        yaxis=dict(title='',tickfont=dict(size=25)),  
        legend=dict(title=None, font=dict(size=25)), 
        height=600,
        width=800,
    )
    return fig


def create_faculty_piechart(data,selected_years):
    soet_data = data[data['year'].isin(selected_years)]
    total_faculty = soet_data['scopus_number_of_faculty'] + soet_data['core_of_WoS_number_of_faculty']
    zero_publications_faculty_percent = soet_data['zero_publications_faculty_percent'] / 100  # Assuming percentage is stored as a value
    remaining_faculty_percent = 1 - zero_publications_faculty_percent
    faculty_data = pd.DataFrame({
        'category': ['Scopus', 'WoS Core', 'Zero Publications'],
        'percentage': [
            (soet_data['scopus_number_of_faculty'] / total_faculty).sum(),
            (soet_data['core_of_WoS_number_of_faculty'] / total_faculty).sum(),
            zero_publications_faculty_percent.sum()
        ]
    })
    fig = px.pie(faculty_data, values='percentage', names='category')
    fig.update_traces(textinfo='percent', textfont_size=25,hoverlabel=dict(font=dict(size=25,color='black')))
    fig.update_layout(
        legend=dict(title=None, font=dict(size=25,color='black'),orientation='v',x=0.75,y=0.50),
        height=600,
        width=800,
        hoverlabel=dict(font=dict(size=25)),
    )
    return fig




def main():
    st.set_page_config(page_title="SOAS - Faculty Dashboard", page_icon="📊", layout="wide")

    # Add custom CSS for styling
    st.markdown(
        """
        <style>
        .main {
            background-color: #FFA600;
            padding: 1rem;
        }

        .card {
            background-color: white;
            padding: 1rem;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .dashboard-title {
            background-color: #377eb8;
            color: white;
            padding: 1rem;
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-bottom: -2rem;
            margin-top:-3rem;
        }

        [data-baseweb="tag"] {
            width:8rem;
            height:4rem;
        } 

        [data-title="Box Select"],[href="https://plotly.com/"],[data-title="Lasso Select"],[data-title="Pan"],[data-title="Zoom"]{
            display:None;
        }

        .st-ar{
            font-size:25px;
        }
        [data-testid="stTable"]{
            font-size:30px;
            background-color:white;
        }


        .st-ci{
            width:1.8rem;
            height:1.8rem;
        }

        .st-af{
            font-size:1.8rem;
        }

        [title="open"]{
            width:4rem;
            height:4rem;
            cursor:pointer;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Fetch data from database
    connection, cursor = connect_to_database()
    df = fetch_data(cursor)
    connection.close()

    # Display sections
    st.markdown("<h1 class='dashboard-title' style='text-align:center;'>Faculty Dashboard</h1>", unsafe_allow_html=True)

    # Sidebar for filtering
    years_filter = st.multiselect(label="",label_visibility='hidden', options=df["year"].unique(), default=df["year"][-1:])


    # st.markdown("---")

    col1, col2 = st.columns(2,gap='small')
    col3 = st.container()

    with col1:
        st.markdown("<h1 class='card' style='text-align:center;'>Faculty Count</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(plot_faculty_stacked_bar(df, years_filter), use_container_width=True)
    with col2:
        st.markdown("<h1 class='card' style='text-align:center;'>Publications</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(create_faculty_piechart(df,years_filter), use_container_width=True) 
    with col3:
        st.markdown("<h1 class='card' style='text-align:center;'>Count of Seminars/Conferences by Faculty</h1><br>", unsafe_allow_html=True)
        st.plotly_chart(plot_seminars(df), use_container_width=True)    
    st.table(df)  
        
if __name__ == "__main__":
    main()
