const express = require('express');
const bodyParser = require('body-parser');
const registerRoute = require('./routes/register');
const loginRoute = require('./routes/login');
const userregisterroute=require('./routes/userregister');
const add_academic_data=require('./routes/add_academic_data');
const add_after_studies_data=require('./routes/add_after_studies_data');
const add_all_data=require('./routes/add_all_data');
const add_college_data=require('./routes/add_college_data');
const add_faculty_data=require('./routes/add_faculty_data');
const userlogin=require('./routes/Userlogin');
const checkEmaiil=require('./routes/checkEmail');
const path = require('path');
const changePasswordRouter = require('./routes/change_password');
const userController = require('./routes/usercontroller');
const academicDataRouter = require('./routes/get_academic_data');
const facultyDataRouter = require('./routes/get_faculty_data');
const afterStudiesDataRouter = require('./routes/get_afterstudies_data');
const collegeDataRouter = require('./routes/get_college_data');
const allDataRouter = require('./routes/get_all_data');
const schoolRoutes = require('./routes/schoolRoutes');
const fetchSchoolsRouter = require('./routes/fetchSchools');
const deleteAccountRouter = require('./routes/delete-account');



const app = express();

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(bodyParser.urlencoded({ extended: true }));

// Parse JSON bodies (as sent by API clients)
app.use(bodyParser.json());

// Define route handler for the registration route
app.use('/register', registerRoute);

app.use('/userregister',userregisterroute)

app.use('/add_academic_data',add_academic_data)
app.use('/add_after_studies_data',add_after_studies_data)
app.use('/add_all_data',add_all_data)
app.use('/add_college_data',add_college_data)
app.use('/add_faculty_data',add_faculty_data)
app.use('/', changePasswordRouter);
// Define route handler for the login route
app.use('/login', loginRoute);
app.use('/Userlogin',userlogin);
app.get('/users', userController.getUsers);
app.get('/admins',userController.getAdmins);
app.use('/',checkEmaiil);
app.delete('/users/delete', userController.deleteUserByEmail);
app.use(express.json());
// Route to update user by email
app.put('/users/:email', userController.updateUser);
app.use('/', academicDataRouter);
app.use('/',facultyDataRouter);
app.use('/',afterStudiesDataRouter);
app.use('/',collegeDataRouter);
app.use('/',allDataRouter);
app.use('/schools', schoolRoutes);
app.use('/fetchSchools', fetchSchoolsRouter); 

// Define route handler for deleting account
app.use('/delete-account', deleteAccountRouter);


// Define route handler for the homepage
app.get('/', (req, res) => {
  // Send the 'homepage.html' file when someone visits the root URL
  res.sendFile(path.join(__dirname, 'public', 'homepage.html'));
});


const db = require('./db/api'); // Replace with your database connection file
// Get all data from a table named 'users'
app.get('/data/:key/:table', async (req, res) => {
  try {
    const key = req.params.key;
    const table = req.params.table
    if(key=="CutmapDeans$12345"){
      const conn = await db.getConnection();
      const queryString = `SELECT * FROM ${table}`;
      const [data] = await conn.query(queryString); // Replace with your table name
      conn.release();
      res.json(data);
    }
    else{
      throw new Error("Invalid Key");
      }
  } catch (error) {
    console.error(error);

    // Provide more specific error messages for different error cases
    if (error.code === 'ER_NOT_FOUND_TABLE') {
      res.status(404).json({ message: 'Table not found' });
    } else if (error.code === 'ER_ACCESS_DENIED_ERROR') {
      res.status(403).json({ message: 'Access denied' });
    } else {
      res.status(500).json({ message: 'Internal server error' });
    }
  }
});

const PORT = process.env.PORT || 3005;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});