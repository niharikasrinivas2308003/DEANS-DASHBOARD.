const db = require('../db/db');

function getUsers(req, res) {
    db.query('SELECT * FROM deanusers', (error, results, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }

        const users = results.map(user => ({ username: user.username, school: user.school, email: user.email }));
        res.json(users);
    });
}

function getAdmins(req, res) {
    db.query('SELECT * FROM adminusers', (error, adminresults, fields) => {
        if (error) {
            console.error('Error querying database:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        const admins = adminresults.map(admin => ({ username: admin.username }));
        res.json(admins);
    });
}

function deleteUserByEmail(req, res) {
    const email = req.query.email;
    if (!email) {
        res.status(400).json({ error: 'Email parameter is missing' });
        return;
    }
    db.query('DELETE FROM deanusers WHERE email = ?', [email], (error, results, fields) => {
        if (error) {
            console.error('Error deleting user:', error);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
        }
        res.json({ message: 'User deleted successfully' });
    });
}

const updateUser = (req, res) => {
    const email = req.params.email;
    const { username, school } = req.body;

    db.query(
        'UPDATE deanusers SET username = ?, school = ? WHERE email = ?',
        [username, school, email],
        (error, results) => {
            if (error) {
                console.error('Error updating user:', error);
                res.status(500).json({ error: 'Internal Server Error' });
            } else {
                res.json({ message: 'User updated successfully' });
            }
        }
    );
};

module.exports = {
    getUsers,
    getAdmins,
    deleteUserByEmail,
    updateUser,
};
