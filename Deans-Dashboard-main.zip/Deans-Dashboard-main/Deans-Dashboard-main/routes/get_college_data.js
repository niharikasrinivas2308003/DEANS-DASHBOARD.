const express = require('express');
const router = express.Router();
const connection = require('../db/db');

// Route to handle GET request for academic data
router.get('/get_college_data', (req, res) => {
  const school = req.query.school;
  const schoolTableMap = {
    soet: 'soet_data',
    soas:'soas_data',
    som:'som_data'
    // Add other schools here if needed
};
const tableName = schoolTableMap[school];
  // Query to select all data from the "soet_data" table
  const query = `SELECT year,number_of_new_full_programs ,number_of_new_domains , number_of_new_skill_courses, highest_H_index, lowest_H_index, faculty_with_zero_H_index,number_of_domains_eligible_for_school,percentage_of_domains_offered,approximate_income_of_school,cost_of_faculty_including_non_teaching	 FROM ${tableName}`;

  // Execute the query
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      res.status(500).send('Error fetching data');
      return;
    }

    // Send the result as JSON
    res.json(results);
  });
});

module.exports = router;
