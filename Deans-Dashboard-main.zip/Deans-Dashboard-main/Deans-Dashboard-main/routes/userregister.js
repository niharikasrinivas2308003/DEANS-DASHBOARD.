const express = require('express');
const router = express.Router();
const db = require('../db/db');

router.post('/', (req, res) => {
    const { dean_username, dean_email, dean_school, dean_password } = req.body;


    db.query('SELECT * FROM deanusers WHERE email = ?', [dean_email], (err, result) => {
        if (err) {
            console.error('Error checking email:', err);
            return res.status(500).send('Error checking email');
        }

        if (result.length > 0) {
            return res.status(400).send('Email already registered');
        } else {
            db.query('INSERT INTO deanusers (username, email,school, password) VALUES (?, ?, ?,?)',
                [dean_username, dean_email, dean_school, dean_password], (err, result) => {
                    if (err) {
                        console.error('Error storing data:', err);
                        return res.status(500).send('Error storing data');
                    }
                    console.log('Data stored successfully');
                    return res.status(200).send('Registration Successful');
                });
        }
    });
});

module.exports = router;