const express = require('express');
const router = express.Router();
const db = require('../db/db');

router.post('/', (req, res) => {
  const { year, facultyCount, phdFacultyCount, seminarCount, scopusCount, coreCount, zeroPubPercent } = req.body;

  // Check if the year exists in the database
  db.query('SELECT * FROM soet_data WHERE year = ?', [year], (err, results) => {
    if (err) {
      console.error('Error querying database:', err);
      return res.status(500).send('Internal Server Error');
    }

    // If year already exists in the database, update the data
    if (results.length > 0) {
      db.query('UPDATE soet_data SET faculty_percent=?,PhD_faculty_percent=?,seminars_conferences_percent=?,scopus_number_of_faculty=?,core_of_WoS_number_of_faculty=?,zero_publications_faculty_percent=? WHERE year = ?', 
                [facultyCount, phdFacultyCount, seminarCount, scopusCount, coreCount, zeroPubPercent, year], 
                (err, results) => {
        if (err) {
          console.error('Error updating database:', err);
          return res.status(500).send('Internal Server Error');
        }
        return res.status(200).send('Data updated successfully');
      });
    } else {
      // If year does not exist in the database, insert the data
      db.query('INSERT INTO soet_data (year,faculty_percent,PhD_faculty_percent,seminars_conferences_percent,scopus_number_of_faculty,core_of_WoS_number_of_faculty,zero_publications_faculty_percent) VALUES (?, ?, ?, ?, ?, ?, ?)',
                [year, facultyCount, phdFacultyCount, seminarCount, scopusCount, coreCount, zeroPubPercent],
                (err, results) => {
        if (err) {
          console.error('Error inserting into database:', err);
          return res.status(500).send('Internal Server Error');
        }
        return res.status(200).send('Data inserted successfully');
      });
    }
  });
});

module.exports = router;
