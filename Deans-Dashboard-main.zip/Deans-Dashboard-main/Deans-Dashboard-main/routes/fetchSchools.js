// fetchSchools.js

const express = require('express');
const router = express.Router();
const db = require('../db/db');

// Route handler for fetching schools
router.get('/', (req, res) => {
    const query = "SELECT email, school FROM deanusers"; // Modify query according to your database schema
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error fetching schools from database: ', err);
            res.status(500).json({ error: 'Error fetching schools from database' });
            return;
        }
        const schools = {};
        results.forEach(row => {
            const domain = row.email.split('@')[1];
            const schoolName = row.school;
            if (!schools[domain]) {
                schools[domain] = [];
            }
            schools[domain].push(schoolName);
        });
        res.json(schools);
    });
});

module.exports = router;
