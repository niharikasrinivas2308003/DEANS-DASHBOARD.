// Import required modules
const express = require('express');
const db = require('../db/db');

// Create a router
const router = express.Router();

// Route to fetch data for a specific school
router.get('/:school', (req, res) => {
    const school = req.params.school;
    const query =` SELECT * FROM ${school}_data ORDER BY year DESC LIMIT 1`; // Replace year_column with the actual column name for year

    // Execute the query
    db.query(query, (err, results) => {
        if (err) {
            console.error('Error executing MySQL query:', err);
            res.status(500).json({ error: 'Database error' });
            return;
        }

        res.json(results); // Send the fetched data as JSON response
    });
});

module.exports = router;
