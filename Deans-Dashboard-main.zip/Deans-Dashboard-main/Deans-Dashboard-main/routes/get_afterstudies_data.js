// get_academic_data.js

const express = require('express');
const router = express.Router();
const connection = require('../db/db');

// Route to handle GET request for academic data
router.get('/get_afterstudies_data', (req, res) => {
  const school = req.query.school;
  const schoolTableMap = {
    soet: 'soet_data',
    soas:'soas_data',
    som:'som_data'
    // Add other schools here if needed
};
const tableName = schoolTableMap[school];
  // Query to select all data from the "soet_data" table
  const query = `SELECT year,students_percent_with_greater_than_10_lpa ,students_percent_with_between_5_10_lpa , students_percent_with_less_than_5_lpa, overall_students_percent_with_placement, students_percent_who_started_startup, ninety_percentile	, students_percent_who_qualified_in_national_exams, students_percent_who_are_pursuing_HE FROM ${tableName}`;

  // Execute the query
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      res.status(500).send('Error fetching data');
      return;
    }

    // Send the result as JSON
    res.json(results);
  });
});

module.exports = router;
