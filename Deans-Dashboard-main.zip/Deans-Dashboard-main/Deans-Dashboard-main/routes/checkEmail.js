// Assuming you have already set up your Express app and connected to your database

const express = require('express');
const db = require('../db/db'); // Assuming this is where you have your database connection
const router = express.Router();

router.post('/checkEmail', (req, res) => {
  const { email, tableName } = req.body;

  // Assuming you are using a database (e.g., MySQL, PostgreSQL) to store user data
  // Modify the SQL query based on the tableName parameter
  const query = `SELECT COUNT(*) AS count FROM ${tableName} WHERE email = ?`;
  db.query(query, [email], (err, result) => {
    if (err) {
      console.error("Database error:", err);
      return res.status(500).json({ error: "An error occurred while checking the email." });
    }
    const exists = result[0].count > 0;
    return res.json({ exists: exists });
  });
});

module.exports = router;
