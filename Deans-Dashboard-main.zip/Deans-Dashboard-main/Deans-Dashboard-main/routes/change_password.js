const express = require('express');
const db = require('../db/db');
const router = express.Router();

router.post('/change_password', (req, res) => {
  const { current_user_email, newPassword, userType } = req.body;

  // Define the table name based on the userType
  let tableName;
  if (userType === 'admin') {
    tableName = 'adminusers';
  } else if (userType === 'dean') {
    tableName = 'deanusers';
  } else {
    return res.status(400).send('Invalid user type');
  }

  // Execute update query
  db.query(`UPDATE ${tableName} SET password = ? WHERE email = ?`, [newPassword, current_user_email], (error, results) => {
    if (error) {
      console.error('Error:', error);
      return res.status(500).send('Failed to change password');
    }
    if (results.affectedRows === 0) {
      return res.status(404).send('User not found');
    }
    res.send('Password changed successfully');
  });
});

module.exports = router;
