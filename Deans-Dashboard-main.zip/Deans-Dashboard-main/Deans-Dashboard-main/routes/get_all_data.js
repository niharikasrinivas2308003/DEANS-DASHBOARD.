// get_academic_data.js

const express = require('express');
const router = express.Router();
const connection = require('../db/db');

// Route to handle GET request for academic data
router.get('/get_all_data', (req, res) => {
  const school = req.query.school;
  const schoolTableMap = {
    soet: 'soet_data',
    soas:'soas_data',
    som:'som_data'
    // Add other schools here if needed
};
const tableName = schoolTableMap[school];
  // Query to select all data from the "soet_data" table
  const query = `SELECT * FROM ${tableName}`;

  // Execute the query
  connection.query(query, (err, results) => {
    if (err) {
      console.error('Error executing query:', err);
      res.status(500).send('Error fetching data');
      return;
    }

    // Send the result as JSON
    res.json(results);
  });
});

module.exports = router;
