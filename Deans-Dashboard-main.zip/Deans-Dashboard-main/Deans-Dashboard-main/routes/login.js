const express = require('express');
const router = express.Router();
const db = require('../db/db');

router.post('/', (req, res) => {
  const { email, password } = req.body;

  // Query the database to find the user with the provided email
  db.query('SELECT * FROM adminusers WHERE email = ? and password = ?', [email, password], (err, results) => {
    if (err) {
      console.error('Error querying database:', err);
      return res.status(500).send('Internal Server Error');
    }

    // If no user found with the provided email
    if (results.length === 0) {
      return res.status(401).send('Invalid email or password');
    }

    const user = results[0];

    // Assuming passwords are stored as plain text (not recommended for production)
    if (password !== user.password) {
      return res.status(401).send('Invalid email or password');
    }

    // If email and password are correct, send a success message
    return res.status(200).json({ message: 'Login successful', username: user.username });
  });
});

module.exports = router;
