
(function () {
    emailjs.init("wY2neZHgl0k85jYZB"); // Initialize EmailJS with your user ID
})();

function checkDataUpdateStatus() {
    
    // Assign specific values to currentTime, currentDayOfMonth, and lastDayOfMonth
    var currentTime = new Date('2024-04-26'); // For example, setting it to April 29th, 2024
    var currentDayOfMonth = currentTime.getDate(); // Get the current day of the month
    var lastDayOfMonth = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, 0).getDate(); // Get the last day of the month
    console.log(currentDayOfMonth);
    console.log(lastDayOfMonth);
    var emailSent = false; // Flag to track if email has been sent
    // Check if the current date is one day before the last day of the month
    if (lastDayOfMonth - currentDayOfMonth === 1) {
        // Send reminder email for monthly categories if email has not been sent yet
        if (!emailSent) {
            sendReminderEmail(['Backlogs', 'Cost of Faculty ( includes non teaching)', 'Publications', 'Discipline or School H index', 'Number of Ph D faculty', 'Number of Seminars/Conferences', 'Number of Seminars/Conferences', 'Multiple Entry Multiple Exit'], 'monthly');
            emailSent = true; // Set the flag to true to indicate that the email has been sent
            console.log('sent email');
        }
    }

    // Check if the current date is the last day of the month
    if (currentDayOfMonth === lastDayOfMonth) {
        // Reset emailSent flag for the new month
        emailSent = false;
        console.log('new month started, emailSent reset to false');
    }




    var emailSent = false; // Flag to track if email has been sent

     // Calculate the last and one day before last day of the week
     var lastDayOfWeek = new Date(currentTime.getFullYear(), currentTime.getMonth(), currentDayOfMonth - currentTime.getDay() + 6);
     var oneDayBeforeLastDayOfWeek = new Date(lastDayOfWeek.getFullYear(), lastDayOfWeek.getMonth(), lastDayOfWeek.getDate() - 1);
     console.log(lastDayOfWeek);
     console.log(oneDayBeforeLastDayOfWeek);
 
     // Reset emailSent flag when a new week starts
     var lastEmailSentDate = new Date(oneDayBeforeLastDayOfWeek); // Initialize the date when the email was last sent
     // If current day is one day before the last day of the week and email has not been sent yet, send reminder email for weekly categories
     if (currentTime.getDate() == oneDayBeforeLastDayOfWeek.getDate() && !emailSent) {
         sendReminderEmail(['Attendance', 'Course Completion'], 'weekly');
         emailSent = true; // Set the flag to true to indicate that the email has been sent
         console.log('emailsent true');
     }
     if (!emailSent) {
         lastEmailSentDate.setDate(lastEmailSentDate.getDate() - lastEmailSentDate.getDay()); // Adjust the date to the last Sunday
         if (currentTime > lastEmailSentDate) {
             emailSent = false; // Reset the flag if the current date is later than the last time email was sent
             console.log('email false');
         }
     }

    var semesterEmailSent = false;
0
    // Check if the current month is April or October to send the semester reminder email
    if (currentTime.getMonth() === 3 || currentTime.getMonth() === 9) {
        // Calculate the last day of the month
        var lastDayOfMonth = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, 0).getDate();
        console.log(lastDayOfMonth);
        // Calculate the last but one day of the month
        var lastButOneDayOfMonth = lastDayOfMonth - 1;
        console.log(lastButOneDayOfMonth);
        // Check if the current day is the last but one day of the month
        if (currentDayOfMonth === lastButOneDayOfMonth) {
            // Send reminder email for semester categories if email has not been sent yet
            if (!semesterEmailSent) {
                sendReminderEmail(['Exam registration', 'Pass percentage', 'Domains offered', 'Apprximate income of the school', 'New domains', 'New skills courses'], 'semester');
                console.log('sent semester email');

                // Set the semesterEmailSent flag to true to indicate that the email has been sent
                semesterEmailSent = true;
            }
        }
    }

    console.log(currentDayOfMonth);
    var yearlyEmailSent = false;

    // Check if the current date is the end of March (yearly reminder)
    if (currentTime.getMonth() === 2 && currentDayOfMonth === 30) {
        // Send reminder email for yearly categories if email has not been sent yet
        if (!yearlyEmailSent) {
            sendReminderEmail(['Placement', 'Higher Education', 'Start ups', 'New full programmes'], 'yearly');
            yearlyEmailSent = true; // Set the flag to true to indicate that the email has been sent
            console.log('sent yearly email');
        }
    }

}


// Function to send reminder emails for the specified categories and timeframe
function sendReminderEmail(categories, timeframe) {
    var emailData = {
        to: '211801380035@cutmap.ac.in', // Replace with the recipient's email address
        name: 'venky', // Replace with the recipient's name
        categories: categories,
        timeframe: timeframe
    };

    // Determine the appropriate template ID based on the timeframe
    var templateId = 'template_ohxenke'; // Replace with the ID of your email template

    // Construct the message body
    var message = 'Reminders for ' + timeframe + ' Data Updates :\n';
    categories.forEach(function (category) {
        message += '- ' + category + '\n';
    });
    emailData.message = message;

    // Send the email
    emailjs.send("service_vy82i1v", templateId, emailData)
        .then(function (response) {
            console.log("Email sent:", response);
        }, function (error) {
            console.error("Email failed to send:", error);
        });
}

// Periodically check data update status and send emails
setInterval(checkDataUpdateStatus, 24 * 60 * 60 * 1000); // Check every 24 hours

// Initial check when the page loads
checkDataUpdateStatus();
