// Function to add options recursively
function addOption(year) {
    if (year <= currentYear) {
        var option = document.createElement("option");
        option.value = year;
        option.text = year;
        selectElement.appendChild(option);
        addOption(year + 1); // Call the function recursively for the next year
    }
}