// Retrieve user email from localStorage
var storedUserEmail = localStorage.getItem('userEmail');

console.log(storedUserEmail);


function deleteAccount() {
    const email = localStorage.getItem('userEmail');

    if (email) {
        // Make sure email is available before proceeding
        const confirmation = confirm("Are you sure you want to delete your account?");
        
        if (confirmation) {
            fetch('/delete-account', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email: email })
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Failed to delete account');
                    }
                    console.log('Account deleted successfully');
                    // Remove email from localStorage
                    localStorage.removeItem('userEmail');
                    // Redirect to homepage.html
                    alert("Account deleted successfully");
                    window.location.href = "/homepage.html";
                })
                .catch(error => {
                    console.error('Error deleting account:', error.message);
                    // Handle error case
                });
        }
    } else {
        console.error('User email not found in localStorage');
        // Handle the case where the email is not available in localStorage
    }
}