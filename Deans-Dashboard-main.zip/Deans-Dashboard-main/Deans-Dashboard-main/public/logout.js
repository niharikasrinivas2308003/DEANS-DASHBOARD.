function logout() {
    // Clear localStorage
    localStorage.clear();
    // Redirect to home page
    window.location.href = "/homepage.html"; // Change "home.html" to the actual URL of your home page
}
